package ficha8;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Scanner;
import java.util.Stack;

public class Ficha8 {

    private List<Integer> idades;

    public static void main(String[] args) {

        Biblioteca b=new Biblioteca();
        String s="bla";
        String c="ble";
        List<String> novo=new ArrayList<>();
        novo.add(c);
        novo.add(s);
        Filme f=new Filme(novo, "a60991", "Must sleep" , "Rafaela", 2, 3, 1, "True Story");
        Scanner scan = new Scanner(System.in);
        String cena;
        Collection<String> localidades = new Stack<>();
        Percurso p=new Percurso(localidades);
       

        System.out.println("Exercício:\n1-Exe1   2-Exe2   3-Exe3   4-Exe4   \n5-Testa(proxLoc, locAvisitar, removeLocalidade) \n6-Adiciona Filme|Album");
        cena = scan.nextLine();
        switch (cena) {
            case "1":
                exe1();
                break;

            case "2":
                exe2(4, 10);
                break;

            case "3":
                exe3(5);
                break;

            case "4":
                exe4();
                break;
                
            case "5":
                p.insereLocalidade("cena");
                p.insereLocalidade("Mirandela");
                p.insereLocalidade("Braga"); //último a ser inserido fica no topo
                p.proxLoc(); // Já avançou para o segundo elemento fez pop ao 1º 
                 p.removeLocalidade("Mirandela"); 
                System.out.println("\nProxima localidade a visitar: " +p.locAVisitar());
                System.out.println("Stack:"+localidades);
                break;
                
            case "6":
               b.adiciona(f);
             
               
             for (Filme a : b.getFilmes().values()) {
                System.out.println(a);
                   
        };
            
        }
    }

    public static void exe1() {
        int n = 1, soma = 0, par = 0, impar = 0;
        float media;
        while (n != 0) {
            Scanner scan = new Scanner(System.in);
            System.out.println("Insira o número:");
            n = scan.nextInt();

            if (n > 0 && n % 2 == 0) {
                par++;
                soma += n;
            } else if (n > 0 && n % 2 != 0) {
                impar++;
            }

        }

        media = (float) soma / par;

        System.out.println("Media:" + media + "\nPares:" + par + "\nImpares:" + impar);

    }

    public static void exe2(int m, int n) {
        float media;
        int soma = 0, total = n, i;
        int cena;
        List<Integer> idades = new ArrayList<>();
        Scanner scan = new Scanner(System.in);

        while (n != 0) {
            System.out.println("Insira idade:");
            cena = scan.nextInt();
            if (cena > m) {
                idades.add(cena);
                soma += cena;
                n--;
            } else {
                soma += cena;
                n--;

            }

        }
        media = (float) (soma) / total;

        System.out.println("\nMedia: " + media);
        System.out.println("Idades maiores que M: " + idades);

    }

    public static void exe3(int n) {
        List<Integer> bla = new ArrayList<>();

        Scanner scan = new Scanner(System.in);
        int a, i = n;
        int s = 0, count = 0;

        while (n != 0 && bla.size() <= i) {
            System.out.println("Insira elemento no Array");
            a = scan.nextInt();

            if (a % 2 == 0) {
                count++;
                n--;
            } else {
                n--;
            }

            bla.add(a);

        }

        System.out.println("\nArray:" + bla);
        System.out.println("Elementos pares: " + count);

    }

    public static void exe4() {
        Scanner scan = new Scanner(System.in);
        String s, a;

        System.out.println("Insira a string: ");
        s = scan.nextLine();

        System.out.println("Insira a subString: ");
        a = scan.nextLine();

        int lastIndex = 0;
        int count = 0;

        while (lastIndex != -1) {

            lastIndex = s.indexOf(a, lastIndex);

            if (lastIndex != -1) {
                count++;
                lastIndex += a.length();
            }
        }
        System.out.println("\nContagem: "+count);

    }
    
    
    
    
}
