/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ficha8;


public class Album {
    private String ident;
    private String titulo;
    private String nome;
    private int musicas;
    private float tempo;
    private int flag;
    private String comentario;

    public Album(String ident, String titulo, String nome, int musicas, float tempo, int flag, String comentario) {
        this.ident = ident;
        this.titulo = titulo;
        this.nome = nome;
        this.musicas = musicas;
        this.tempo = tempo;
        this.flag = flag;
        this.comentario = comentario;
    }
    
    public Album(Album a){
        this.ident=a.getIdent();
        this.titulo=a.getTitulo();
        this.nome=a.getNome();
        this.musicas=a.getMusicas();
        this.tempo=a.getTempo();
        this.flag=a.getFlag();
        this.comentario=a.getComentario();
    }
    
    public Album(){
        this.ident=new String();
        this.titulo=new String();
        this.nome=new String();
        this.musicas=0;
        this.tempo=0;
        this.flag=0;
        this.comentario=new String();
    }

    public String getIdent() {
        return ident;
    }

    public void setIdent(String ident) {
        this.ident = ident;
    }

    public String getTitulo() {
        return titulo;
    }

    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public int getMusicas() {
        return musicas;
    }

    public void setMusicas(int musicas) {
        this.musicas = musicas;
    }

    public float getTempo() {
        return tempo;
    }

    public void setTempo(float tempo) {
        this.tempo = tempo;
    }

    public int getFlag() {
        return flag;
    }

    public void setFlag(int flag) {
        this.flag = flag;
    }

    public String getComentario() {
        return comentario;
    }

    public void setComentario(String comentario) {
        this.comentario = comentario;
    }
    
    public String toString(){
        StringBuilder s=new StringBuilder();
        s.append("Identificador:" + this.getIdent());
        s.append("Titulo: " + this.getTitulo());
        s.append("Nome: " + this.getNome());
        s.append("Musicas: " + this.getMusicas());
        s.append("Tempo: " + this.getTempo());
        s.append("Flag" + this.getFlag());
        s.append("Comentario: " +this.getComentario());
        
       return s.toString();
    
    
    }
    
    public boolean equals(Object o){
    if(this==o)
        return true;
    
    if((o==null)|| this.getClass() != o.getClass())
        return false;
    
    else{
        Album i=(Album) o;
        return (this.ident.equals(i.getIdent()) && this.titulo.equals(i.getTitulo()) && this.nome.equals(i.getNome()) && this.getMusicas()==(i.getMusicas()) && this.tempo==(i.getTempo()) && this.flag==(i.getFlag()) && this.comentario.equals(i.getComentario()));
    }
    }
    
    
    
}
