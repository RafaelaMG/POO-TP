
package ficha8;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Rafaela
 */
public class Filme extends Album {

    private List<String> actores;

    public Filme(List<String> actores, String ident, String titulo, String nome, int musicas, float tempo, int flag, String comentario) {
        super(ident, titulo, nome, musicas, tempo, flag, comentario);
        this.actores = actores;
    }

    public Filme(Filme f) {
        super(f);
        this.actores = f.getActores();
    }

    public Filme() {
        super();
        this.actores = new ArrayList<>();
    }

    public List<String> getActores() {
        List<String> nova = new ArrayList<>();
        for (String s : actores) {
            nova.add(s);

        }
        return nova;
    }
    
    public String toString(){
        StringBuilder s=new StringBuilder();
        s.append("Identificação:" + this.getIdent());
        s.append("\nTitulo: " + this.getTitulo());
        s.append("\nNome:" + this.getNome());
        s.append("\nMusicas: " + this.getMusicas());
        s.append("\nTempo:" + this.getTempo());
        s.append("\nFlag:" + this.getFlag());
        s.append("\nComentario:" + this.getComentario());
        s.append("\nActores:" + this.getActores());
        
        return s.toString();
    }

    public boolean equals(Object o){
        if(this==o)
            return true;
        if((o==null)|| this.getClass() != o.getClass())
            return false;
    else {
    Filme i=(Filme)o;
    return(this.actores.equals(i.getActores()));
}
}
}