/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ficha8;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import java.util.Map;
import java.util.Objects;

/**
 *
 * @author Rafaela
 */
public class Biblioteca {
    private Map<String,Filme> filmes;

    public Biblioteca(Map<String,Filme> add) {
        this.filmes = add;
    }
    
    public Biblioteca (Biblioteca b){
        this.filmes=b.getFilmes();
    }
    
    public Biblioteca(){
        this.filmes=new HashMap<>();
    }
    
    public Map<String,Filme> getFilmes(){
        Map<String,Filme> novo=new HashMap<>();
        for(Filme a: filmes.values())
            novo.put(a.getNome(), a);
    
        return novo;
    }
    
    
    public void adiciona(Filme f){
            this.filmes.put(f.getTitulo(), f);
    }
    
    public Map<String,Filme> procura(String nome){
        Map<String, Filme> novo=new HashMap<>();
        for(Filme f: filmes.values()){
        if(this.filmes.containsKey(nome))
          novo.put(nome, f);
        }
        return novo;
    }
    
    public List<Filme> procuraFilme(String nome){

        List<Filme> novo=new ArrayList<>();
   
        for(Filme f: filmes.values()){
            for(String s: f.getActores())
            if(f.getActores().contains(nome))
                novo.add(f);
        } return novo;
    }
    
    
     public void gravaObj(String fich) throws IOException {
        ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(fich));
        oos.writeObject(this);
        
        oos.flush();
        oos.close();
    }
    
    public static Biblioteca leObj(String fich) throws IOException, ClassNotFoundException {
        ObjectInputStream ois = new ObjectInputStream(new FileInputStream(fich));
        
        Biblioteca te = (Biblioteca) ois.readObject();
        
        ois.close();
        return te;
    }

    @Override
    public String toString() {
        return "Biblioteca{" + "filmes=" + filmes + '}';
    }

    @Override
    public int hashCode() {
        int hash = 3;
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Biblioteca other = (Biblioteca) obj;
        if (!Objects.equals(this.filmes, other.filmes)) {
            return false;
        }
        return true;
    }
    
    
    
    
    
}
