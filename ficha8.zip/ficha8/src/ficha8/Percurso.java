/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ficha8;

import java.util.Collection;
import java.util.Stack;

public class Percurso {

    private String nomePercurso;
    // localidades do percurso já visitadas
    private Stack< String> locsVisitadas;
// localidades ainda por visitar
    private Stack< String> locsPorVisitar;
   

    public Percurso(Collection<String> localidades) {
        this.locsPorVisitar=(Stack<String>) localidades;

    }

    public String locAVisitar() {
        String s = locsPorVisitar.peek();

        return s;
    }

    public void proxLoc() {
        String s = locsPorVisitar.pop();
        
    }

    public void removeLocalidade(String loc) {
        if (locsPorVisitar.contains(loc)) {
            locsPorVisitar.remove(loc);
        }

    }

    //para teste
    public void insereLocalidade(String loc) {
        if (!locsPorVisitar.contains(loc)) {
            locsPorVisitar.add(loc);
        }

    }

}
